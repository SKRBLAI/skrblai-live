export const percySyncAgent = {
  syncCRM: async () => {
    // TODO: Implement daily CRM sync logic
    return { success: true, syncedRecords: 0 };
  }
}; 