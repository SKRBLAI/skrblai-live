export const sitegenAgent = {
  generateWebsite: async (requirements: any) => {
    // TODO: Implement site generation logic
    return { success: true, websiteCode: "" };
  }
}; 