export const percyAgent = {
  processInput: async (input: string) => {
    // TODO: Implement Percy AI logic
    return { success: true, response: "Percy AI response" };
  },
  submitIntakeForm: async (formData: any) => {
    // TODO: Implement form submission logic
    return { success: true };
  }
};